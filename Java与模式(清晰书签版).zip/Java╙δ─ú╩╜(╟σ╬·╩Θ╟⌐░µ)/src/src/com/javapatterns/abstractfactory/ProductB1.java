package com.javapatterns.abstractfactory;

public class ProductB1 implements ProductB
{
    public ProductB1()
    {
    }
}
