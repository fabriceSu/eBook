package com.javapatterns.abstractfactory;

public class ProductA2 implements ProductA
{
    public ProductA2()
    {
    }
}
