package com.javapatterns.abstractfactory.exercise1;

public class MacRam implements Ram
{
}
