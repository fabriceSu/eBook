package com.javapatterns.abstractfactory.exercise1;

public class MacCpu implements Cpu
{
}
