package com.javapatterns.abstractfactory.exercise1;

public interface Cpu
{
}
