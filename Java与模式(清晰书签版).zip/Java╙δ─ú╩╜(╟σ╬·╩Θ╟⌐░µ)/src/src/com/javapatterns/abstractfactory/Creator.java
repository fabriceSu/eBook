package com.javapatterns.abstractfactory;

public interface Creator
{
    public ProductA factoryA();

	public ProductB factoryB();
}
