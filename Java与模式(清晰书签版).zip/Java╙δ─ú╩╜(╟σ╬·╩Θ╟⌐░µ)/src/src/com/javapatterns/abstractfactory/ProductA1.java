package com.javapatterns.abstractfactory;

public class ProductA1 implements ProductA
{
    public ProductA1()
    {
    }
}
