package com.javapatterns.abstractfactory.computer;

public interface Cpu
{
}
