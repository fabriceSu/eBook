package com.javapatterns.abstractfactory;

public class ProductB2 implements ProductB
{
    public ProductB2()
    {
    }
}
