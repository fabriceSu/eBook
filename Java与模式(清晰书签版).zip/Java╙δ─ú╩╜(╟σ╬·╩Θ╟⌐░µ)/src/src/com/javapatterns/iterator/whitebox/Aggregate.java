package com.javapatterns.iterator.whitebox;

abstract public class Aggregate
{
    public Iterator createIterator()
    {
        return null;
    }
}
