package com.javapatterns.iterator.blackbox;

abstract public class Aggregate
{
    public Iterator createIterator()
    {
        return null;
    }
}
