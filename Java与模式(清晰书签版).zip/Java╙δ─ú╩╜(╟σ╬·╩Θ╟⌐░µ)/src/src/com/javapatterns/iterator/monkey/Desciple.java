package com.javapatterns.iterator.monkey;

abstract public class Desciple
{
    abstract public void speak();
}
