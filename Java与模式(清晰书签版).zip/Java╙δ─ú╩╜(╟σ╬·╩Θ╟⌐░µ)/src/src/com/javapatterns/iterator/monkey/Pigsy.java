package com.javapatterns.iterator.monkey;

public class Pigsy extends Desciple
{
    public void speak()
    {
		System.out.println("I am Pigsy");
    }
}
