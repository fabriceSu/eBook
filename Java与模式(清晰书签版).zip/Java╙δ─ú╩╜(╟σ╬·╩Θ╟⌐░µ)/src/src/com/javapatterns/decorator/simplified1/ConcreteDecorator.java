package com.javapatterns.decorator.simplified1;

public class ConcreteDecorator extends Decorator
{
    public void sampleOperation()
    {
        super.sampleOperation();
    }
}
