package com.javapatterns.decorator;

public interface Component
{
    void sampleOperation();
}
