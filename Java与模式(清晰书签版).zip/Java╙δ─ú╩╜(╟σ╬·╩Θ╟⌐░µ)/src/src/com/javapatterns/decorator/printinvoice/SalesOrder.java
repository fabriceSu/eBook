package com.javapatterns.decorator.printinvoice;

public class SalesOrder extends Order
{
    public SalesOrder() {
    }

    public void print()
    {
        super.print();
    }
}
