package com.javapatterns.decorator;

public class ConcreteDecorator extends Decorator
{
    public void sampleOperation()
    {
        super.sampleOperation();
    }
}
