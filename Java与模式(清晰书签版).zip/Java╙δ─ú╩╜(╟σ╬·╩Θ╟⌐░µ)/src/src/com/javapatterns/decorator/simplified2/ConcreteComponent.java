
package com.javapatterns.decorator.simplified2;

public class ConcreteComponent implements Component {
    public void sampleOperation(){
        // Write your code here
    }
}
