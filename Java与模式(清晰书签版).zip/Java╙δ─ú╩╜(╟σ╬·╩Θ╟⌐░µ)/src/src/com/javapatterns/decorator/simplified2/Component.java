
package com.javapatterns.decorator.simplified2;

public interface Component {
    void sampleOperation();
}
