package com.javapatterns.flyweight.coffeestall;

public abstract class Order
{  
    public abstract void serve();

    public abstract String getFlavor();

}