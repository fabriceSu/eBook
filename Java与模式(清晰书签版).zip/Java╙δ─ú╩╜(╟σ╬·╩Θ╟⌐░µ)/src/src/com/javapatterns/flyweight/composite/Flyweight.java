package com.javapatterns.flyweight.composite;

abstract public class Flyweight
{
    abstract public void operation(String state); 
}
