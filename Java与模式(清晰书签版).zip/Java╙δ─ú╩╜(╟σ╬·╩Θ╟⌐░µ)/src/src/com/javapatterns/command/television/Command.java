package com.javapatterns.command.television;

public interface Command
{
    void execute();
}
