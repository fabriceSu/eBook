package com.javapatterns.command.stocktrader;

public interface Command
{
    public abstract void execute ( ); 
}
