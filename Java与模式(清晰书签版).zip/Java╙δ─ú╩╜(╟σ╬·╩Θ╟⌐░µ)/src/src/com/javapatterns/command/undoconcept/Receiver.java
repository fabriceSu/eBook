package com.javapatterns.command.undoconcept;

public class Receiver
{
    public Receiver()
    {
        //write code here
    }

    public void action()
    {
        System.out.println("Action has been taken.");
    }
}
