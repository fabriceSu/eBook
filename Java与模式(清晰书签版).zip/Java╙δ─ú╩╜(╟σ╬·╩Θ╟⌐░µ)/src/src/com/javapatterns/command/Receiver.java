package com.javapatterns.command;

public class Receiver
{
    public Receiver()
    {
        //write code here
    }

    public void action()
    {
        System.out.println("Action has been taken.");
    }
}
