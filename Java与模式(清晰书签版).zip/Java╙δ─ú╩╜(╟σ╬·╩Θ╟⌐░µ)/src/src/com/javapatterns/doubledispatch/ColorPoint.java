package com.javapatterns.doubledispatch;

import java.awt.Color;
import java.awt.Canvas;

public class ColorPoint extends Point 
{
	private Color c;
    public ColorPoint() {
    }

    public void draw(Canvas C)
    {
     	//Color point code
    }
}
