package com.javapatterns.doubledispatch.overload;

abstract public class Horse
{
}
