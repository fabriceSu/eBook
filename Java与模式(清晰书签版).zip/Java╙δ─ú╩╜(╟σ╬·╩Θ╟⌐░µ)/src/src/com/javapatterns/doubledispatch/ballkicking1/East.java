package com.javapatterns.doubledispatch.ballkicking1;

abstract public class East
{
	public abstract void goEast(West west);

    /** @link dependency */
    /*# West lnkWest; */
}
