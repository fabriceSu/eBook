package com.javapatterns.composite.drawingsafe;

public class Rectangle extends Graphics 
{
    public void draw()
    {
        //write your code here
    }
}

