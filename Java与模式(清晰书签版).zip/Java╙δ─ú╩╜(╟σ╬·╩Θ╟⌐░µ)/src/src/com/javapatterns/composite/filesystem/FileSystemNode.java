package com.javapatterns.composite.filesystem;

public class FileSystemNode
{
    public FileSystemNode() {
    }

    public int getSize()
    {            return 0;
    }
}
