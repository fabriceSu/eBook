package com.javapatterns.composite;

public interface Component {
    Composite getComposite();

    void sampleOperation();
}
