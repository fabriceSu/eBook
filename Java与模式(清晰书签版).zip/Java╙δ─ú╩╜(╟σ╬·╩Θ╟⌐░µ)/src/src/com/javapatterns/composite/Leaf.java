package com.javapatterns.composite;

public class Leaf implements Component {
    public Composite getComposite(){
        // Write your code here
        return null;
    }

    public void sampleOperation(){
        // Write your code here
    }
}
