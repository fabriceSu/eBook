package com.javapatterns.bridge;

abstract public class Implementor
{
    public abstract void operationImp();
}
