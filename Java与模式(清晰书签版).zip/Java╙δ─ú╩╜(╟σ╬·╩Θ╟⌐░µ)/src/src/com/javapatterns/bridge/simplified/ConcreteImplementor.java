package com.javapatterns.bridge.simplified;

import com.javapatterns.bridge.Implementor;
public class ConcreteImplementor 
{
    public void operationImp()
    {
        System.out.println("Do something...");
    }
}
