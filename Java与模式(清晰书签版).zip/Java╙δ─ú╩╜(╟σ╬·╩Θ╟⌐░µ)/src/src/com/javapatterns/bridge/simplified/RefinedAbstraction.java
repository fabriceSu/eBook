package com.javapatterns.bridge.simplified;

public class RefinedAbstraction extends Abstraction
{
    public void operation()
    {
    	//write your code here
    }
}
