package com.javapatterns.bridge.imageviewer;

public class LinuxImageImpl extends ImageImpl
{
    public void init()
    {
        //load the info of the image
    }

    public void paint()
    {
        //display the image onto screen.
    }
}
