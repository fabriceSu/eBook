
package com.javapatterns.bridge.airplanes2;

public class MD extends AirplaneMaker
{
	public void produce()
    {
		//Write your code here
    }
}
