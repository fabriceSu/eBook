
package com.javapatterns.bridge.airplanes2;

public class Boeing extends AirplaneMaker
{
	public void produce()
    {
		//Write your code here
    }
}
