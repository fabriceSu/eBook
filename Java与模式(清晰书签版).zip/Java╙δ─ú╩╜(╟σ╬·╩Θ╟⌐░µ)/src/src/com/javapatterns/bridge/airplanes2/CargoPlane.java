
package com.javapatterns.bridge.airplanes2;

public class CargoPlane extends Airplane
{
	public void fly()
    {
		//Write your code here
    }
}
