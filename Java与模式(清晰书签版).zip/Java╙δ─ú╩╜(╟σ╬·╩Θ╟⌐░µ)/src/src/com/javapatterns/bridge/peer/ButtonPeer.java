package com.javapatterns.bridge.peer;

public class ButtonPeer extends ComponentPeer {
    public void setLabel(String text) {
    }

}
