package com.javapatterns.bridge.peer;


public class MotifButtonPeer extends ButtonPeer {
}
