package com.javapatterns.builder;

public class Product
{
    public Product()
    {
        //Write your code here
    }
}
