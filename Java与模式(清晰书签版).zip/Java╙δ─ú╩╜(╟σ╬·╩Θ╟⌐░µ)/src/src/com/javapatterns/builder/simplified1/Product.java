package com.javapatterns.builder.simplified1;

public class Product
{
    public Product()
    {
        //default constructor
    }
}
