package com.javapatterns.builder.extended;

public class Product1 implements Product
{
    public Product1()
    {
        //Write your code here
    }
}
