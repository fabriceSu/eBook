package com.javapatterns.builder.extended1;

public class Product3 implements Product
{
    public Product3()
    {
        //Write your code here
    }
}
