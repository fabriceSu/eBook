package com.javapatterns.factorymethod;

public class ConcreteProduct2 implements Product
{
	public ConcreteProduct2()
    {
		System.out.println("CocnreteProduct2 is being created.");
    }
}
