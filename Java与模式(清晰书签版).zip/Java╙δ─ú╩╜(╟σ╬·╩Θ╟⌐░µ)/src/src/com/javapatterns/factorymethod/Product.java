package com.javapatterns.factorymethod;

public interface Product
{
}
