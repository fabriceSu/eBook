package com.javapatterns.factorymethod;

public class ConcreteProduct1 implements Product
{
	public ConcreteProduct1()
    {
		System.out.println("CocnreteProduct1 is being created.");
    }
}
