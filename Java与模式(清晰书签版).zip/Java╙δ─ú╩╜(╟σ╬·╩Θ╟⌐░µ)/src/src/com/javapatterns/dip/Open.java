package com.javapatterns.dip;

public class Open extends AccountStatus
{
    public void sendCorrespondence()
    {
        //write your code here
    }
}
