package com.javapatterns.dip;

abstract public class AccountStatus
{
    public abstract void sendCorrespondence();
}
