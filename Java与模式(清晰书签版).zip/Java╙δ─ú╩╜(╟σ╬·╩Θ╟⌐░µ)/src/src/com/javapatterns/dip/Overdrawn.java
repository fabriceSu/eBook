package com.javapatterns.dip;

public class Overdrawn extends AccountStatus
{
    public void sendCorrespondence()
    {
        //write your code here
    }
}
