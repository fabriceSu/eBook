package com.javapatterns.facade;

public class SignalOutput
{ 

	public SignalOutput()
	{
	}
	
	public void sigStar()
	{ 
	
		System.out.print("sigStar");
	
	}
	
	
	public void sigRectangle()
	{ 
	
		System.out.print("sigRect");
	
	}
	
	public void sigCircle()
	{ 
	
		System.out.print("?"); 
	
	} 

} 
