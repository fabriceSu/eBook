package com.javapatterns.facade;

public class StringOutput
{ 
	
	public StringOutput()
	{
	}
	
	public void StringOut(String str)
	{ 
	
		System.out.println(str); 
	
	} 

}


