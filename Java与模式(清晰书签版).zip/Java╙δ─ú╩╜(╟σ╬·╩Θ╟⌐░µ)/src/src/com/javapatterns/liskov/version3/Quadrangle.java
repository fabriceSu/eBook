package com.javapatterns.liskov.version3;

public interface Quadrangle
{
    public long getWidth();

    public long getHeight();
}
