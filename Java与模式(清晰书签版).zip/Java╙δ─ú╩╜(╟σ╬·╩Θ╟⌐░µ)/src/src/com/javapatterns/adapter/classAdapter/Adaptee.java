package com.javapatterns.adapter.classAdapter;

public class Adaptee {
    public void sampleOperation1(){}
}
